from unittest.util import _MAX_LENGTH
from django.db import models
class Student(models.Model):
    rno = models.CharField(max_length=10)
    sname = models.CharField(max_length=20)
    branch = models.CharField(max_length=20)
    fees = models.IntegerField(max_length=20)
    def __str__(self):
        return "rno is "+ str(self.rno)  + "name is "+ str(self.sname) + " branch is "+ str(self.branch) + " fees is "+str(self.fees)
class Job(models.Model):
    jobtitle = models.CharField(max_length=100)
    jobdescription = models.CharField(max_length=500)
class Candidate(models.Model):
    email = models.CharField(max_length=50)
    jobid = models.IntegerField()
    applydate = models.CharField(max_length=50)
    cname=models.CharField(max_length=50)
class Registration(models.Model):
    userid=models.CharField(max_length=50)
    password=models.CharField(max_length=50)  
    mobileno=models.CharField(max_length=12)  
    fullname=models.CharField(max_length=50)