from django.shortcuts import render,redirect
from . models import Student
def index(request):
    data = Student.objects.all()
    if request.method=="POST":
        stu = Student.objects.filter(rno=request.POST["txtrno"])
        if stu.count()==0:
          s = Student(rno=request.POST["txtrno"],sname=request.POST["txtsname"],
          branch=request.POST["txtbranch"],fees=int(request.POST["txtfees"]))
          s.save()
          return render(request,"guest/index.html",
          {"res":"data inserted successfully","d":data,"d1":data})
        else:
          return render(request,"guest/index.html",
          {"res":"data not inserted, this rno already exist","d":data,"d1":data})    
    
    return render(request,"guest/index.html",{"d":data,"d1":data})
def searchrec(request):
   stu = Student.objects.filter(rno=request.POST["ddlsearch"])
   return render(request,"guest/index.html",
   {"d":stu,"d1":Student.objects.all()}) 
def editstu(request):
    if request.method=="POST":
      r = Student.objects.get(pk=request.POST["txtid"])
      r.rno = request.POST["txtrno"]
      r.sname = request.POST["txtsname"]
      r.branch = request.POST["txtbranch"]
      r.fees = request.POST["txtfees"]
      r.save()
      return redirect('/guest')
    rec = Student.objects.get(pk=request.GET["q"])
    return render(request,"guest/editstu.html",{"res":rec})
def deletestu(request):
    rec = Student.objects.get(pk=request.GET["q"])
    return render(request,"guest/deletestu.html",{"res":rec})    
def about(request):
    return render(request,"guest/about.html")

def services(request):
    return render(request,"guest/services.html")    