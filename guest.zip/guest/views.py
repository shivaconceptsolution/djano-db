from django.shortcuts import render,redirect
from . models import Student,Job,Candidate,Registration
def index(request):
    data = Student.objects.all()
    if request.method=="POST":
        stu = Student.objects.filter(rno=request.POST["txtrno"])
        if stu.count()==0:
          s = Student(rno=request.POST["txtrno"],sname=request.POST["txtsname"],
          branch=request.POST["txtbranch"],fees=int(request.POST["txtfees"]))
          s.save()
          return render(request,"guest/index.html",
          {"res":"data inserted successfully","d":data,"d1":data})
        else:
          return render(request,"guest/index.html",
          {"res":"data not inserted, this rno already exist","d":data,"d1":data})    
    
    return render(request,"guest/index.html",{"d":data,"d1":data})
def searchrec(request):
   stu = Student.objects.filter(rno=request.POST["ddlsearch"])
   return render(request,"guest/index.html",
   {"d":stu,"d1":Student.objects.all()}) 
def editstu(request):
    if request.method=="POST":
      r = Student.objects.get(pk=request.POST["txtid"])
      r.rno = request.POST["txtrno"]
      r.sname = request.POST["txtsname"]
      r.branch = request.POST["txtbranch"]
      r.fees = request.POST["txtfees"]
      r.save()
      return redirect('/guest')
    rec = Student.objects.get(pk=request.GET["q"])
    return render(request,"guest/editstu.html",{"res":rec})
def deletestu(request):
    if request.method=="POST":
      r = Student.objects.get(pk=request.POST["txtid"])
      r.delete()
      return redirect('/guest')
    rec = Student.objects.get(pk=request.GET["q"])
    return render(request,"guest/deletestu.html",{"res":rec})    
def about(request):
    return render(request,"guest/about.html")

def services(request):
    return render(request,"guest/services.html")    
def job(request):
  if(request.session.has_key('sessuid')):
   suid=request.session['sessuid']
   job = Job.objects.all()
   return render(request,"guest/job.html",{"res":job})
  else:
    return redirect('login')  
def candidate(request):
  job = Job.objects.all()
  if request.method=="POST":
    s = Candidate(email=request.POST["txtemail"],jobid=int(str(request.POST["ddljob"])),applydate=request.POST["txtapplydate"],cname=request.POST["txtcandidate"])
    s.save()
    return render(request,"guest/candidate.html",{"res":job,"msg":"data inserted successsfully"})
  return render(request,"guest/candidate.html",{"res":job,"jid":int(request.GET["q"])})    
def register(request):
  if request.method=="POST":
    r = Registration(userid=request.POST["txtuid"],password=request.POST["txtpass"],mobileno=request.POST['txtmobile'],fullname=request.POST['txtfname'])
    r.save()
    return render(request,"guest/reg.html",{"res":"data insertion successfully"}) 
  return render(request,"guest/reg.html")  
def login(request):
  if request.method=="POST":
    r = Registration.objects.filter(userid=request.POST["txtuid"],password=request.POST["txtpass"])
    if r.count()>0:
      request.session["sessuid"]=request.POST["txtuid"]
      return redirect('job')
    else:
      return render(request,"guest/login.html",{"res":"invalid userid and password"}) 
  return render(request,"guest/login.html")    

def logout(request):
   del  request.session["sessuid"]
   return redirect('login')