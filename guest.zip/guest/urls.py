from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('viewcandidate',views.candidate,name='candidate'),
    path('job',views.job,name='job'),
    path('editstu',views.editstu,name='editstu'),
    path('deletestu',views.deletestu,name='deletestu'),
    path('searchrec',views.searchrec,name='searchrec'),
    path('about',views.about,name='about'),
    path('services',views.services,name='services'),
    path('register',views.register,name='register'),
    path('login',views.login,name='login'),
    path('logout',views.logout,name='logout')

]